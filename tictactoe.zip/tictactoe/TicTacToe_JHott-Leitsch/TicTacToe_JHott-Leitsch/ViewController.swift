//
//  ViewController.swift
//  TicTacToe_JHott-Leitsch
//
//  Created by student on 2/4/17.
//  Copyright © 2017 jhott-leitsch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var player = "X"

    @IBOutlet weak var playerLabel: UILabel!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        sender.setTitle((player), for: .normal)
        
        var text = ""

        if player == "X" {
            player = "O"
            text = "Player 2 Go"
            
        } else {
             player = "X"
             text = "Player 1 Go"
            
        }
        playerLabel.text = text
    }

    
    
    }




